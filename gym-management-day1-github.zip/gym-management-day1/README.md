# Gym Management System

A web-based Gym Management System built according to the project proposal using **React, Vite, Tailwind CSS, Supabase and TanStack Query**.

## Day 1 — Project Foundation

Day 1 completes the foundation required by the project plan:

- React + Vite frontend initialized
- Tailwind CSS configured
- Supabase JavaScript client installed and configured
- TanStack Query installed and configured
- Basic project folder structure created
- Environment-based Supabase configuration prepared
- Initial dashboard/module UI created
- Git/GitHub-ready project structure prepared

## Technology Stack

- **Frontend:** React 19 + Vite
- **Styling:** Tailwind CSS v4
- **Backend & Database:** Supabase / PostgreSQL
- **Authentication:** Supabase Auth
- **Data Fetching & Caching:** TanStack Query + Supabase JS Client
- **Version Control:** Git + GitHub
- **Deployment:** Vercel (planned)

## Project Modules

1. Authentication & Roles
2. Member Management
3. Membership Plans
4. Classes & Scheduling
5. Class Booking & Waitlist
6. Attendance / Check-In
7. Payments & Renewals
8. Dashboard & Basic Reports
9. Streak Tracker
10. Fee Reminder Banner

## Environment Setup

Copy `.env.example` to `.env` and add your Supabase project credentials:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

**Never commit `.env` to GitHub.**

## Run Locally

```bash
npm install
npm run dev
```

Then open the local Vite URL shown in the terminal.

## Day 1 Status

**Foundation setup completed.**

Next planned task: create the `profiles` and `members` tables in Supabase and configure the first Row-Level Security (RLS) policies.