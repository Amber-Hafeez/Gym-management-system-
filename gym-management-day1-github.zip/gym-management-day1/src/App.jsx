const modules = [
  ["01", "Authentication & Roles", "Supabase Auth and role-based access"],
  ["02", "Member Management", "Manage gym member records"],
  ["03", "Membership Plans", "Plans, assignments and expiry dates"],
  ["04", "Classes & Scheduling", "Manage trainers, classes and capacity"],
  ["05", "Class Booking", "Booking and waitlist management"],
  ["06", "Attendance / Check-In", "Track daily member visits"],
  ["07", "Payments & Renewals", "Record payments and renew plans"],
  ["08", "Dashboard & Reports", "Daily gym statistics and summaries"],
  ["09", "Streak Tracker", "Track consecutive member check-ins"],
  ["10", "Fee Reminder", "Show upcoming membership expiry reminders"]
];

function App() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b bg-slate-900 text-white">
        <div className="mx-auto max-w-6xl px-5 py-8">
          <p className="mb-2 text-sm font-medium text-slate-300">
            Gym Management System
          </p>
          <h1 className="text-3xl font-bold tracking-tight">
            Project Foundation
          </h1>
          <p className="mt-2 max-w-2xl text-slate-300">
            Day 1 setup using React, Vite, Tailwind CSS and Supabase.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 py-10">
        <section className="mb-8">
          <h2 className="text-2xl font-bold">Dashboard Preview</h2>
          <p className="mt-1 text-slate-600">
            Foundation UI prepared for the upcoming gym management modules.
          </p>
        </section>

        <section className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Active Members" value="0" />
          <StatCard title="Today's Check-ins" value="0" />
          <StatCard title="Expiring Soon" value="0" />
          <StatCard title="Monthly Revenue" value="Rs. 0" />
        </section>

        <section className="mt-10">
          <h2 className="text-xl font-bold">Planned Modules</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {modules.map(([number, title, description]) => (
              <div
                key={number}
                className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
              >
                <span className="text-sm font-semibold text-slate-400">
                  {number}
                </span>
                <h3 className="mt-2 font-semibold">{title}</h3>
                <p className="mt-1 text-sm text-slate-600">{description}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-10 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="font-bold">Day 1 Status</h2>
          <p className="mt-2 text-sm text-slate-600">
            React + Vite, Tailwind CSS, Supabase JS client and TanStack Query
            are configured. Supabase environment variables are prepared
            without exposing credentials in the repository.
          </p>
        </section>
      </main>
    </div>
  );
}

function StatCard({ title, value }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
      <p className="text-sm text-slate-500">{title}</p>
      <p className="mt-2 text-2xl font-bold">{value}</p>
    </div>
  );
}

export default App;